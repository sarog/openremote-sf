//$Id: NonUniqueResultException.java 10235 2006-08-08 23:08:58Z epbernard $
package javax.persistence;

/**
 * Thrown by the persistence provider when getSingleResult() is executed on a query and there is more than
 * one result from the query. This exception will not cause the current transaction, if one is active, to be
 * marked for roll back.
 *
 * @author Gavin King
 */
public class NonUniqueResultException extends PersistenceException {

	/**
	 * Constructs a new NonUniqueResultException exception with null as its detail message
	 */
	public NonUniqueResultException() {
		super();
	}

	/**
	 * Constructs a new NonUniqueResultException exception with the specified detail message
	 * 
	 * @param message
	 */
	public NonUniqueResultException(String message) {
		super( message );
	}

}
