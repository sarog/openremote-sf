//$Id:$
//EJB3 Specification Copyright 2004-2006 Sun Microsystems, Inc.

/**
 * The javax.persistence package contains the classes and interfaces that define the contracts
 * between a persistence provider and the managed classes and the clients of the Java Persistence API.
 */
package javax.persistence;

