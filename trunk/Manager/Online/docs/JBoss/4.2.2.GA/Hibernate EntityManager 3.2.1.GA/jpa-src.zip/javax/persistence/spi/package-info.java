//$Id:$
//EJB3 Specification Copyright 2004-2006 Sun Microsystems, Inc.

/**
 * The javax.persistence.spi package defines the classes and interfaces that are implemented by the
 * persistence provider and the Java EE container for use by the container, provider, and/or Persistence
 * bootstrap class in deployment and bootstrapping.
 */
package javax.persistence.spi;

